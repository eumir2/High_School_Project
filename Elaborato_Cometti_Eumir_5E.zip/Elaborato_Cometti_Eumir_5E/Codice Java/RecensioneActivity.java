package com.example.valtellinaround;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class RecensioneActivity extends AppCompatActivity {
    //attributi
    private String idP;
    private String idU;
    private String nome;
    private String recensione;
    private float rating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recensione);
        nome =  getIntent().getStringExtra("nome");
        idP =  getIntent().getStringExtra("idP");
        idU = getIntent().getStringExtra("idU");
        TextView n = findViewById(R.id.n);
        n.setText(nome);
        //Toast.makeText(this,idP  + " "+ idU, Toast.LENGTH_SHORT).show();

    }

    //metodo che controlla la recensione
    public boolean controllaRecensione(){
        RatingBar r = findViewById(R.id.rating);
        TextView rec = findViewById(R.id.recensione);

        rating = r.getRating();
        recensione = rec.getText().toString();

        System.out.println(rating+ "         " + recensione);

        //controllo che i campi non siano vuoti
        if(rating == 0){
            SweetAlertDialog p = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
            p.setContentText("Valore nel rating non inserito");
            p.show();
            return  false;
        }
        if (recensione.equals("")) {
            SweetAlertDialog p = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
            p.setContentText("Valore nelle note  non inserito");
            p.show();
            return false;
        }
        return true;
    }

    //metodo che invia la recensione
    public void inviaRecensione(View view) {
        //controllo che i campi inseriti siano compatibili
        if(controllaRecensione() == true) {

            //creo l'url per contattare la pagina
            URL s = null;
            try {
                s = new URL("http://eumircometti.altervista.org/Tesina/caricaRecensione.php");
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }


            String parametri = "?idU=" + idU + "&idP=" + idP + "&recensione=" + recensione + "&rating=" + rating;

            //contatto la pagina
            String tmp = sendRecensione(s, parametri);
            if (tmp.equals("")) {
                SweetAlertDialog p = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                p.setContentText("Recensione inserita con successo");
                p.show();
                finish();
            } else {
                SweetAlertDialog p = new SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE);
                p.setContentText("Inserimento recensione fallito");
                p.show();
            }
        }
    }




    //metodo che scarica i dati del punto dal DB contattando la pagina altervista
    public String sendRecensione(URL url, String parametri){
        //La seguente direttiva è solo per evitare di usare
        // i thread o AsyncTask, poiché le attività di rete
        // andrebbero fatte in parallelo all&#39;esecuzione
        // dell&#39;interfaccia
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        StringBuilder sb = null;
        try {
            URL u;
            HttpURLConnection urlConnection = null;
            u = new URL(url+parametri);
            urlConnection = (HttpURLConnection) u.openConnection();
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader = null;
            reader = new BufferedReader(new InputStreamReader(in));
            sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                // accoda la risposta del web server in una stringa
                sb.append(line + "\n");
                //System.out.println(line);
            }
            String text = sb.toString();
            // mostra la risposta del web server nella console
            System.out.println(text);
            return text;
        } catch (Exception e) {e.printStackTrace();}
        return "Lettura Fallita";
    }

    //metodo che termina la recensione
    public void endRecensione(View view){
        finish();
    }
}