package com.example.valtellinaround;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class RecensioniActivity extends AppCompatActivity {
    //attributi
    private String idP;
    private String nomeP;
    private float media;
    private RecensioneAdapter adapter;

    //insieme delle recensioni del punto interesse
    private ArrayList<Recensione> recensioni = new ArrayList<Recensione>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recensioni);





        idP =  getIntent().getStringExtra("idP");
        nomeP =  getIntent().getStringExtra("nomeP");


        //contatto il DB
       String s = null;
        try { s = getRecensioni(new URL("http://eumircometti.altervista.org/Tesina/scaricaRecensioni.php"),"?idP="+idP); }
        catch (MalformedURLException e) { e.printStackTrace(); }



        //elaboro i dati
        try { elaboraJson(s); }
        catch (JSONException e) { e.printStackTrace(); }




    }



    //metodo che contatta lo script PHP per scariare le recensioni
    public String getRecensioni(URL url, String parametri){
        //La seguente direttiva è solo per evitare di usare
        // i thread o AsyncTask, poiché le attività di rete
        // andrebbero fatte in parallelo all&#39;esecuzione
        // dell&#39;interfaccia
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        StringBuilder sb = null;
        try {
            URL u;
            HttpURLConnection urlConnection = null;
            u = new URL(url+parametri);
            urlConnection = (HttpURLConnection) u.openConnection();
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader = null;
            reader = new BufferedReader(new InputStreamReader(in));
            sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                // accoda la risposta del web server in una stringa
                sb.append(line + "\n");
                //System.out.println(line);
            }
            String text = sb.toString();
            // mostra la risposta del web server nella console
            System.out.println(text);
            return text;
        } catch (Exception e) {e.printStackTrace();}
        return "Lettura Fallita";
    }

    //metodo che elabora i dati e riempie l'arraylist
    public void elaboraJson(String t) throws JSONException {
        float tmp = 0;
        //creo un JsonArray temporaneo
        JSONArray recensioniArray = new JSONArray(t);
        for (int i = 0; i < recensioniArray.length(); i++) {
            //salvo tutti i valori in variabili temporanee
            JSONObject arrayObj = recensioniArray.getJSONObject(i);
            String  nomeU =  arrayObj.getString("nomeU");
            String note =  arrayObj.getString("note");
            float rating =  Float.parseFloat(arrayObj.getString("rating"));

            //sommo tutti i valori per il calcolo della media
            tmp += rating;

            //creo la recensione e la aggiungo all ArrayList
            recensioni.add(new Recensione(nomeU, note, rating));
        }
        //calcolo la media
        media = tmp/recensioniArray.length();

        //carico il layout
        setLayout();
    }

    //metodo che carica tutti i dati nell activity
    public void setLayout(){
        TextView t = findViewById(R.id.nP);
        t.setText(nomeP);

        TextView me = findViewById(R.id.media);
        me.setText("Media recensioni : "+media);

        ListView listView;
        listView = findViewById(R.id.listView);

        adapter = new RecensioneAdapter(this, R.layout.recensione, recensioni);

        listView.setAdapter(adapter);
    }
}