package com.example.valtellinaround;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback , GoogleMap.OnMarkerClickListener{

    //attributi
    private GoogleMap mMap;

    //varibili dobve salvo il nome utente e l'id del punto
    private String nomeU;
    private String idU;

    //arraylist contenente tutti i punti
    private ArrayList<PuntoInteresse> punti = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        nomeU =  getIntent().getStringExtra("nomeU");
        idU =  getIntent().getStringExtra("idU");
        //Toast.makeText(this,nomeU + " "+ idU, Toast.LENGTH_SHORT).show();

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.clear();
        // Add a marker in Sydney and move the camera
        LatLng torreDiSantaMaria = new LatLng(46.233391, 9.852124);
        // mMap.addMarker(new MarkerOptions().position(torreDiSantaMaria).title("Marker in Torre di Santa Maria").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(torreDiSantaMaria, 8));
        loadMarkers();

    }

    //metodo che visualizza i marker sulla mappa
    public void loadMarkers(){
        //prendo i punti
        String tmp = getPunti();

        //li salvo nell'arraylist
        try { elaboraJson(tmp); }
        catch (JSONException e) { e.printStackTrace(); }

        //creo i markers e li aggiungo alla mappa
        for (PuntoInteresse num : punti) {
            LatLng posizione = new LatLng(num.getLat(), num.getLon());
            MarkerOptions marker = new MarkerOptions().position(posizione).title(num.getId()+";"+num.getNome());
            marker.icon(bitmapDescriptorFromVector(this, R.drawable.ic_baseline_location_on_24));
            mMap.addMarker(marker);
            mMap.setOnMarkerClickListener(this);
        }
    }

    //metodo che scarica i punti dal db contattando la pagina  http://eumircometti.altervista.org/Tesina/ScaricaPunti.php
    public String getPunti(){
        //La seguente direttiva è solo per evitare di usare
        // i thread o AsyncTask, poiché le attività di rete
        // andrebbero fatte in parallelo all&#39;esecuzione
        // dell&#39;interfaccia
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        StringBuilder sb = null;
        try {
            URL url;
            HttpURLConnection urlConnection = null;
            url = new URL(" http://eumircometti.altervista.org/Tesina/ScaricaPunti.php");
            urlConnection = (HttpURLConnection) url.openConnection();
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader = null;
            reader = new BufferedReader(new InputStreamReader(in));
            sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                // accoda la risposta del web server in una stringa
                sb.append(line + "\n");
                //System.out.println(line);
            }
            String text = sb.toString();
            // mostra la risposta del web server nella console
            //System.out.println(text);
            return text;
        } catch (Exception e) {e.printStackTrace();}
        return "Lettura Fallita";
    }

    //metodo che elabora i dati dei punti e li salva nell'arraylist punti
    public void elaboraJson(String t) throws JSONException {
        JSONArray puntiArray = new JSONArray(t);
        for (int i = 0; i < puntiArray.length(); i++) {
            JSONObject arrayObj = puntiArray.getJSONObject(i);
            String id =  arrayObj.getString("idPunto_interesse");
            String nome =  arrayObj.getString("nome");
            double lat =  Double.parseDouble(arrayObj.getString("lat"));
            double lon =  Double.parseDouble(arrayObj.getString("lon"));
            String descrizione =  arrayObj.getString("descrizione");
            String link =  arrayObj.getString("link");
            String telefono =  arrayObj.getString("telefono");
            PuntoInteresse tmp = new PuntoInteresse(id, nome, lat, lon, descrizione, link, telefono);
            punti.add(tmp);
        }
    }

    //metodo che crea la bitmap per il marker
    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
        //Toast.makeText(this,"Cliccato "+ marker.getTitle(), Toast.LENGTH_SHORT).show();
        String[] tmp = marker.getTitle().split(";");
        String idP = tmp[0];
        Intent punto = new Intent(MapsActivity.this, PuntoActivity.class);
        Bundle b = new Bundle();
        b.putString("idP",idP);
        b.putString("idU",idU);
        punto.putExtras(b);
        startActivity(punto);
        return false;
    }
}