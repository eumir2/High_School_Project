package com.example.valtellinaround;

public class Utente {
    //attributi
    private String id;
    private String nome;
    private String password;

    //costruttore standard
    public Utente(String id, String n, String p){
        this.id = new String(id);
        nome = new String(n);
        password = new String(p);
    }

    //setter e getter
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
