package com.example.valtellinaround;

public class Recensione {
    private String idRecensione;
    private String idUtente;
    private String idPuntoInteresse;
    private String note;
    private float rating;

    //attributi secondari
    private String nomeU;


    //costruttre standard
    public Recensione(String idR, String idU, String idP, String n, float r){
        idRecensione = new String(idR);
        idUtente = new String(idU);
        idPuntoInteresse = new String(idP);
        note = new String(n);
        rating = r;
    }

    //costruttore per la singola recensione da mostrare
    public Recensione(String nomeU, String n, float r){
        this.nomeU = new String(nomeU);
        note = new String(n);
        rating = r;

    }

    //setter e getter
    public String getIdRecensione() {
        return idRecensione;
    }

    public void setIdRecensione(String idRecensione) {
        this.idRecensione = idRecensione;
    }

    public String getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(String idUtente) {
        this.idUtente = idUtente;
    }

    public String getIdPuntoInteresse() {
        return idPuntoInteresse;
    }

    public void setIdPuntoInteresse(String idPuntoInteresse) {
        this.idPuntoInteresse = idPuntoInteresse;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getNome(){return nomeU;}
}
