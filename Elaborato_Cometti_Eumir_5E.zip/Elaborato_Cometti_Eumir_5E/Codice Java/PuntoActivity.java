package com.example.valtellinaround;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

import static android.graphics.Color.rgb;

public class PuntoActivity extends AppCompatActivity {

    //attributo in cui salvo l'id del punto
    private String idP;

    //attributo in cui salvo l'id del utente che ha effettuato l'accesso
    private String idU;
    private PuntoInteresse p;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_punto);

        idP =  getIntent().getStringExtra("idP");
        idU = getIntent().getStringExtra("idU");
       // Toast.makeText(this,idP  + " "+ idU, Toast.LENGTH_SHORT).show();
        String s = null;
        try { s = getPunto(new URL("http://eumircometti.altervista.org/Tesina/scaricaPunto.php"),"?idP="+idP); }
        catch (MalformedURLException e) { e.printStackTrace(); }


        //System.out.println(s );
        //elaboro i dati
        try { elaboraJson(s); }
        catch (JSONException e) { e.printStackTrace(); }

        //creo il fragment per mostrare la mappa
        Fragment mappa = new MapFragment(p.getLat(), p.getLon());
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.frame_layout, mappa)
                .commit();

    }


    //metodo che scarica i dati del punto dal DB contattando la pagina altervista
    public String getPunto(URL url, String parametri){
        //La seguente direttiva è solo per evitare di usare
        // i thread o AsyncTask, poiché le attività di rete
        // andrebbero fatte in parallelo all&#39;esecuzione
        // dell&#39;interfaccia
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        StringBuilder sb = null;
        try {
            URL u;
            HttpURLConnection urlConnection = null;
            u = new URL(url+parametri);
            urlConnection = (HttpURLConnection) u.openConnection();
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader = null;
            reader = new BufferedReader(new InputStreamReader(in));
            sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                // accoda la risposta del web server in una stringa
                sb.append(line + "\n");
                //System.out.println(line);
            }
            String text = sb.toString();
            // mostra la risposta del web server nella console
            System.out.println(text);
            return text;
        } catch (Exception e) {e.printStackTrace();}
        return "Lettura Fallita";
    }

    //metodo che elabora i dati presi dal db
    public void elaboraJson(String t) throws JSONException {
        JSONArray puntiArray = new JSONArray(t);
        for (int i = 0; i < puntiArray.length(); i++) {
            JSONObject arrayObj = puntiArray.getJSONObject(i);
            String id =  arrayObj.getString("idPunto");
            String nome =  arrayObj.getString("nome");
            double lat =  Double.parseDouble(arrayObj.getString("lat"));
            double lon =  Double.parseDouble(arrayObj.getString("lon"));
            String descrizione =  arrayObj.getString("descrizione");
            String link =  arrayObj.getString("link");
            String telefono =  arrayObj.getString("telefono");
            p = new PuntoInteresse(id, nome, lat, lon, descrizione, link, telefono);
        }
        //System.out.println(p.toString());
        setLayout();
    }

    //metodo che carica i dati per renderli visibili
    public void setLayout(){
        TextView nome = findViewById(R.id.nomePunto);
        TextView descrizione = findViewById(R.id.descrizione);
        TextView link = findViewById(R.id.link);
        TextView telefono = findViewById(R.id.telefono);

        //inserisco i dati
        nome.setText(p.getNome());
        descrizione.setText(p.getDescrizione());
        link.setText(p.getLink());
        if(p.getTelefono().equals("")) { telefono.setText("Non presente"); }
        else telefono.setText(p.getTelefono());


    }

    //creo lo
    public void getRecensione(View view){
        SweetAlertDialog s = new SweetAlertDialog(this, SweetAlertDialog.NORMAL_TYPE);
        s.setContentText("Vuoi recensire '"+p.getNome()+"'?");

        s.setConfirmButton("SI", new SweetAlertDialog.OnSweetClickListener() {
            @Override
            //se seleziono "SI", carico l'activity per la recensione
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                startRecensione();
            }
        });
        s.setCancelButton("NO", new SweetAlertDialog.OnSweetClickListener() {
            @Override
            //se seleziono "NO" elimino il dialog
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                s.hide();
            }
        });
        s.show();
    }

    //metodo che crea l'activity una volta premuto il bottone
    public void startRecensione(){
        Intent punto = new Intent(PuntoActivity.this, RecensioneActivity.class);
        Bundle b = new Bundle();
        b.putString("nome",p.getNome());
        b.putString("idP",idP);
        b.putString("idU",idU);
        punto.putExtras(b);
        startActivity(punto);
    }

    //avvio l'activity per mostrare le recensioni del punto selezionato
    public void startRecensioni(){
        Intent recensioni = new Intent(PuntoActivity.this, RecensioniActivity.class);
        Bundle b = new Bundle();
        b.putString("idP",p.getId());
        b.putString("nomeP",p.getNome());
        recensioni.putExtras(b);
        startActivity(recensioni);
    }

    public void startRecensioni(View view) {
        startRecensioni();
    }
}