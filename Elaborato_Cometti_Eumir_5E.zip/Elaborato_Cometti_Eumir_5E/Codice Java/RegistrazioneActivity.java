package com.example.valtellinaround;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;

import cn.pedant.SweetAlert.SweetAlertDialog;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

public class RegistrazioneActivity extends AppCompatActivity {
    //attributi
    private String nomeU;
    private String pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrazione);
    }

    //metodo che prende i dati della registrazione
    public void getRegistrazione() throws NoSuchAlgorithmException {
        EditText n = findViewById(R.id.nome);
        EditText p1 = findViewById(R.id.pw1);
        EditText p2 = findViewById(R.id.pw2);

        // controllo che il nome sia inserito
        if( TextUtils.isEmpty(n.getText())){
            n.setError( "Campo obbligatorio!" );
        }
        else {
            //controllo che le password siano inserite
            if (TextUtils.isEmpty(p1.getText())) {
                p1.setError("Campo obbligatorio!");
            } else {
                if (TextUtils.isEmpty(p2.getText())) {
                    p2.setError("Campo obbligatorio!");
                }
                else {
                    if (p1.getText().toString().equals(p2.getText().toString())) {
                        nomeU = n.getText().toString();

                        //cripto la password
                        pw = cripta(p1.getText().toString());


                        //inserisco l'utente e controllo se non è gia presente
                        inserisciUtente();

                    }else Toast.makeText(this,"Password non corrispondenti", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


    //metodo che invia l'utente allo script php che lo inserirà nel DB
    public void inserisciUtente(){
        String s = send();
        //System.out.println(s);
        if(s.equals("") == TRUE){
            saD("i");
            //rieffettuo il login per memorizzare l'utente
            caricaLogin();
        }else {
            saD("e");
        }
    }

    //metodo che invia i dati dell'utente allo script php
    public String send() {
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        String parametri = "?nomeU=" + nomeU + "&pw=" + pw;
        try {
            URL url;
            HttpURLConnection urlConnection = null;
            url = new URL("http://eumircometti.altervista.org/Tesina/caricaUtenti.php"+parametri);
            //System.out.println(parametri);
            urlConnection = (HttpURLConnection) url.openConnection();

            //leggo la risposta della pagina web
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader=null;
            reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder sb = new StringBuilder();
            String line = null;
            while((line = reader.readLine()) != null)
            {
                // accoda la risposta del web server in una stringa
                sb.append(line +'\n');
            }
            //ritorno la risposta dal server
            System.out.println(sb.toString());
            return(sb.toString());

        } catch (Exception e) { e.printStackTrace(); }
        //altrimenti ritorno null
        return "NULL";
    }

    //metodo che cripta le password per l accesso al db
    private String cripta(String p) throws NoSuchAlgorithmException {
        String plaintext = p;
        MessageDigest m = MessageDigest.getInstance("MD5");
        m.reset();
        m.update(plaintext.getBytes());
        byte[] digest = m.digest();
        BigInteger bigInt = new BigInteger(1, digest);
        String hashtext = bigInt.toString(16);
// Now we need to zero pad it if you actually want the full 32 chars.
        while (hashtext.length() < 32) {
            hashtext = "0" + hashtext;
        }
        return hashtext;
    }

    //metodo che carica i login
    public void caricaLogin(){
        Intent login = new Intent(RegistrazioneActivity.this, MainActivity.class);
        startActivity(login);
    }

    //metodo che crea lo SweetAlertDialog
    public void saD(String c){
        if(c.equals("i") == TRUE) {
            //creo il dialog per la conferma dell'iscrizione avvenuta
            SweetAlertDialog p = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
            p.setContentText("Registrazione avvenuta con successo");
            p.show();
        }
        else{
            //creo il dialog per informare l'utente che è gia presente
            SweetAlertDialog p = new SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE);
            p.setContentText("Utente già presente");
            p.show();
        }
    }

    //metodo che termina l'activity
    public void goBack(View view){finish(); }


    public void getRegistrazione(View view) {
        try { getRegistrazione(); }
        catch (NoSuchAlgorithmException e) { e.printStackTrace(); }
    }

}