package com.example.valtellinaround;

import android.content.Context;
import android.icu.text.Transliterator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class RecensioneAdapter extends ArrayAdapter<Recensione> {

    private Context mContext;
    private int mResource;

    public RecensioneAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Recensione> objects) {
        super(context, resource, objects);

        this.mContext = context;
        this.mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);

        Recensione tmp = getItem(position);

         convertView = layoutInflater.inflate(mResource, parent, false);

         //System.out.println(tmp.getNome()+ "aaaaaaaaaaaaaaaa");

        TextView u = convertView.findViewById(R.id.utente);

        RatingBar r = convertView.findViewById(R.id.ratingBar);

        TextView n = convertView.findViewById(R.id.note);

        u.setText(tmp.getNome());

        r.setRating(tmp.getRating());

        n.setText(tmp.getNote());

        notifyDataSetChanged();

        return convertView;
    }
}
