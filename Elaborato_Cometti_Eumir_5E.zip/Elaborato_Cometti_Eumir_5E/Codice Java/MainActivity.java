package com.example.valtellinaround;

import androidx.annotation.VisibleForTesting;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import static java.lang.Boolean.TRUE;

public class MainActivity extends AppCompatActivity{

    //variabili in cui salvo le credenziali dell'utente per il controllo delle password
    //e dell' id per le recensioni
    private String nomeUtente;
    private String pw;
    private String idU;

    //stringa temporanea contenent tutti gli utenti
    private String tmp;

    //arraylist contenente gli utenti
    private ArrayList<Utente> utenti = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tmp = getUtenti();

        //salvo gli utenti nell'arraylist
        try { elaboraJson(tmp); }
        catch (JSONException e) { e.printStackTrace(); }
    }

    //metodo che legge l'elenco degli utenti dal DB situato su http://eumircometti.altervista.org/Tesina/scaricaUtenti.php
    public String getUtenti(){
        //La seguente direttiva è solo per evitare di usare
        // i thread o AsyncTask, poiché le attività di rete
        // andrebbero fatte in parallelo all&#39;esecuzione
        // dell&#39;interfaccia
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        StringBuilder sb = null;
        try {
            URL url;
            HttpURLConnection urlConnection = null;
            url = new URL(" http://eumircometti.altervista.org/Tesina/scaricaUtenti.php");
            urlConnection = (HttpURLConnection) url.openConnection();
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader = null;
            reader = new BufferedReader(new InputStreamReader(in));
            sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                // accoda la risposta del web server in una stringa
                sb.append(line + "\n");
                //System.out.println(line);
            }
            String text = sb.toString();
            // mostra la risposta del web server nella console
            //System.out.println(text);
            return text;
        } catch (Exception e) {e.printStackTrace();}
        return "Lettura Fallita";
    }

    //metodo che elabora i dati e da Json li trasforma in stringhe e le mette nei relativi vettori
    public void elaboraJson(String t) throws JSONException {
        JSONArray utentiArray = new JSONArray(t);
        for (int i = 0; i < utentiArray.length(); i++) {
            JSONObject arrayObj = utentiArray.getJSONObject(i);
            String idU = arrayObj.getString("idUtente");
            String nU = arrayObj.getString("nome_utente");
            String pU = arrayObj.getString("password");
            Utente p = new Utente(idU, nU, pU);
            utenti.add(p);
        }
    }


    //metodo che prende i dati di accesso dell'utente
    public void getDatiAccesso() {
        EditText nome = findViewById(R.id.nomeUtente);
        nomeUtente = nome.getText().toString();

        // controllo che il nome sia inserito
            if( TextUtils.isEmpty(nome.getText())){
                nome.setError( "Campo obbligatorio!" );
        }
        else {
            EditText password = findViewById(R.id.password);
            String pwTmp = password.getText().toString();

            //controllo che la passowrd sia inserita
            if (TextUtils.isEmpty(password.getText())) {
                password.setError("Password obbligatoria!");
            }else {
                //cripto la password
                try { pw = cripta(pwTmp); }
                catch (NoSuchAlgorithmException e) { e.printStackTrace(); }

                controllaUtente();
            }
        }
    }

    public void getIscrizione(){
        Intent iscrizione = new Intent(MainActivity.this, RegistrazioneActivity.class);
        startActivity(iscrizione);
    }

    //metodo che cripta le password per l accesso al db
    private String cripta(String p) throws NoSuchAlgorithmException {
        String plaintext = p;
        MessageDigest m = MessageDigest.getInstance("MD5");
        m.reset();
        m.update(plaintext.getBytes());
        byte[] digest = m.digest();
        BigInteger bigInt = new BigInteger(1, digest);
        String hashtext = bigInt.toString(16);
// Now we need to zero pad it if you actually want the full 32 chars.
        while (hashtext.length() < 32) {
            hashtext = "0" + hashtext;
        }
        return hashtext;
    }



    //metodo che controlla che l'utente sia presente all' interno del db
    public void controllaUtente(){
        //presuppongo che l'utente non sia presente
        int controllo = 0;

        //controllo che l'utente sia  presente
        for (Utente u : utenti) {
            String n = u.getNome();
            String p = u.getPassword();
            if(n.equals(nomeUtente) == TRUE  && p.equals(pw) == TRUE) {
                //se presente imposto il controllo a 1
                controllo = 1;
                //prelevo l'id per le operazioni future
                idU = u.getId();
                break;
            }
        }
        //carico la mappa
        if(controllo == 1)  caricaMappa();
        //altrimenti comunico l'errore
        else  Toast.makeText(this,"Utente non presente", Toast.LENGTH_SHORT).show();
    }

    //metodo che carica la mappa dove mostrare tutti i marker, passando anche il nome utente
    public void caricaMappa(){
        Intent map = new Intent(MainActivity.this, MapsActivity.class);
        Bundle b = new Bundle();
        b.putString("nomeU",nomeUtente);
        b.putString("idU",idU);
        map.putExtras(b);
        startActivity(map);
    }


    public void getDatiAccesso(View view) {
        getDatiAccesso();
    }

    public void getIscrizione(View view) { getIscrizione();}
}
