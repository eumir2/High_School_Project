package com.example.valtellinaround;

import android.media.midi.MidiManager;

import java.util.ArrayList;

public class PuntoInteresse {
    //attributi
    private String id;
    private String nome;
    private double lat;
    private double lon;
    private String descrizione;
    private String link;
    private String telefono;


    //costruttore Standard
    public PuntoInteresse(String id, String n, double lat, double lon, String d, String link, String telefono){
        this.id = new String(id);
        nome = new String(n);
        this.lat =lat;
        this.lon = lon;
        descrizione = new String(d);
        this.link = new String(link);
        this.telefono = new String(telefono);
    }

    //costruttore di copia
    public PuntoInteresse(PuntoInteresse p){
        id = new String(p.id);
        nome = new String(p.nome);
        lat = p.lat;
        lon = p.lon;
        descrizione = new String(p.descrizione);
        link = new String(p.link);
        telefono = new String(p.telefono);
    }

    //setter e getter
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = new String(id);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLon() {
        return lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    //toString
    public String toString(){
        return id+";"+nome+";"+lat+";"+lon+";"+descrizione+";"+link+";"+telefono+";";
    }
}
