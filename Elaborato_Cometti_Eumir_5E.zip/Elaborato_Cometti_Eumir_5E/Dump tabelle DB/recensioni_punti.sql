-- phpMyAdmin SQL Dump
-- version 4.1.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mag 31, 2021 alle 19:03
-- Versione del server: 8.0.21
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_eumircometti`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `recensioni_punti`
--

CREATE TABLE IF NOT EXISTS `recensioni_punti` (
  `idRecensione` int NOT NULL AUTO_INCREMENT,
  `idUtente` varchar(100) NOT NULL,
  `idPunto_interesse` int NOT NULL,
  `recensione` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `rating` float DEFAULT NULL,
  PRIMARY KEY (`idRecensione`),
  KEY `idUtente` (`idUtente`),
  KEY `idPunto_interesse` (`idPunto_interesse`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci AUTO_INCREMENT=18 ;

--
-- Dump dei dati per la tabella `recensioni_punti`
--

INSERT INTO `recensioni_punti` (`idRecensione`, `idUtente`, `idPunto_interesse`, `recensione`, `rating`) VALUES
(1, '2', 21, 'Miglior lago della valtellina', 5),
(2, '3', 60, 'interessante struttura', 3),
(3, '7', 29, 'interessante struttura arcaica', 4),
(4, '7', 38, 'pomeriggio divertente ma troppi pochi servizi', 3),
(5, '11', 5, 'chiesa piu bella della valtellina', 4),
(7, '10', 26, 'molto suggestivo', 3.5),
(8, '10', 63, 'veramente ottimo', 5),
(9, '9', 21, 'non soddisfatto ', 2),
(10, '9', 29, 'Mal gestito, nemmeno un punto di ristoro', 1),
(11, '9', 43, 'Veramente soddisfatto dei servizi e del personale', 5),
(12, '10', 21, 'molto siggestivo ma non il massimo', 3),
(13, '10', 46, 'pomeriggio divertente', 3),
(14, '10', 21, 'non mi e piaciuto per niente', 1),
(15, '12', 21, 'Molto bello e piacevole ', 5),
(16, '13', 26, 'molto sporco e freddo', 2),
(17, '13', 65, 'bella ', 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
