-- phpMyAdmin SQL Dump
-- version 4.1.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mag 31, 2021 alle 19:03
-- Versione del server: 8.0.21
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_eumircometti`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE IF NOT EXISTS `utenti` (
  `idUtente` int NOT NULL AUTO_INCREMENT,
  `nome_utente` varchar(100) DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`idUtente`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci AUTO_INCREMENT=14 ;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`idUtente`, `nome_utente`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'Eumir Cometti', 'b9e508d7685022294c4dc64675ecfdf7'),
(3, 'buca lonetti', '4326e218a685486937f5843ff6a19483'),
(4, 'lol', 'admins'),
(7, 'pippo pluto', '0c88028bf3aa6a6a143ed846f2be1ea4'),
(8, 'pluto ', 'c6009f08fc5fc6385f1ea1f5840e179f'),
(9, 'pippo', '0c88028bf3aa6a6a143ed846f2be1ea4'),
(10, 'itis', '41b90bf71e3d767203050e091ae0145f'),
(11, 'mattei', '7cbb30c3145dab2327a1b9270480b6f0'),
(12, 'gaiadellaghelfa ', 'b94258ef53506bbb4fc3630e72a871fd'),
(13, 'i', '865c0c0b4ab0e063e5caa3387c1a8741');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
