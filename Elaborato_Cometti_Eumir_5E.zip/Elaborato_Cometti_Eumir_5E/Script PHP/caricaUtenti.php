<?php
//script php che prende gli utenti e li carica nel db
//leggo gli attributi dell'utente
  $nomeU=$_GET['nomeU'];
  $pw=$_GET['pw'];
  
  //variablie per il controllo dell'utente
  $c = 1; //se è settata a 1 significa che l'utente è gia presente
  
  //li stampo
  if ( !empty($_GET) ) {
  	//echo "Arrivati:".$nomeU.";".$pw.";";
  }
  //mi connetto al db
  $con = new mysqli("localhost","eumircometti","","my_eumircometti");
	if($con -> connect_errno){
		die("Errore nella connnessione");
	}
 //controllo che l'utente non sia gia presente con una SELECT
 $query = 'SELECT * FROM utenti
 		  WHERE nome_utente = "'.$nomeU.'"
          AND password = "'.$pw.'";';
          
 //echo $query;
  $result=$con->query($query);
  if ($result == TRUE) {
  //echo(mysqli_num_rows($result));
      if(mysqli_num_rows($result) == 0){$c = 0;}
	}
    else {echo "Selezione fallita" . $con->error;}
    
 //inserisco l'utente nel db se non è già presente
 if($c == 0){
      $query = 'INSERT INTO utenti(nome_utente, password) 
              VALUES("'.$nomeU.'",
                      "'.$pw.'");';
      //echo "Utente non presente";
      if ($con->query($query) === TRUE) {}
      else {echo "Errore nell'inserimento" . $con->error;}
    }else{echo "utente già presente";}
?>