<?php
//file PHP che prende i dati dei punti d interesse dal database altervista e li stampa a video;

//mi connetto al database
$con = new mysqli("http://eumircometti.altervista.org/TripAdvisor","eumircometti","","my_eumircometti");
if($con -> connect_errno){
	die("Errore nella connnessione");
}

//estraggo li contenuto della tabella 'ristoranti'
$query = "SELECT * FROM punti_interesse;";

$heroes = array();  
$stmt= $con->query($query);

 //var_dump($stmt);
//looping through all the records
while($riga = $stmt->fetch_assoc()){
 //pushing fetched data in an array 
 $temp = [
 'idPunto_interesse'=>$riga['idPunto_interesse'],
 'nome'=>$riga['nome'],
 'lat'=>$riga['lat'],
 'lon'=>$riga['lon'],
 'descrizione'=>$riga['descrizione'],
 'link'=>$riga['link'],
 'telefono'=>$riga['telefono'],
 ];
 //var_dump($temp);
 //pushing the array inside the hero array 
 array_push($heroes, $temp);
}
 
//displaying the data in json format 
echo json_encode($heroes);

$con->close(); 
?>