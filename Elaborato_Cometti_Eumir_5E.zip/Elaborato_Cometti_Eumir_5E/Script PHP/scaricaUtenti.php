<?php
//file PHP che prende i dati degli utenti dal database altervista e li stampa a video;

//mi connetto al database
$con = new mysqli("http://eumircometti.altervista.org","eumircometti","","my_eumircometti");
if($con -> connect_errno){
	die("Errore nella connnessione");
}

//estraggo li contenuto della tabella 'utenti'
$query = "SELECT * FROM utenti;";

$heroes = array();  
$stmt= $con->query($query);

 //var_dump($stmt);
//looping through all the records
while($riga = $stmt->fetch_assoc()){
 //pushing fetched data in an array 
 $temp = [
 'idUtente'=>$riga['idUtente'],
 'nome_utente'=>$riga['nome_utente'],
 'password'=>$riga['password'],
 ];
 //var_dump($temp);
 //pushing the array inside the hero array 
 array_push($heroes, $temp);
}
 
//displaying the data in json format 
echo json_encode($heroes);

$con->close(); 
?>