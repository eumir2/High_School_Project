<?php
//script php che prende la recensione e la carica nel db
//leggo gli attributi della recensione
  $idU=$_GET['idU'];
  $idP=$_GET['idP'];
  $recensione = $_GET['recensione'];
  $rating = $_GET['rating'];
  
  
  //li stampo
  if ( !empty($_GET) ) {
  	//echo "Arrivati:".$idU.";".$idP.";".$recensione.";".$rating;
  }
  //mi connetto al db
  $con = new mysqli("localhost","eumircometti","","my_eumircometti");
	if($con -> connect_errno){
		die("Errore nella connnessione");
	}
    
 //creo la query
   $query = 'INSERT INTO recensioni_punti(idUtente, idPunto_interesse, recensione, rating) 
             VALUES("'.$idU.'",
                      "'.$idP.'",
                      "'.$recensione.'",
                      "'.$rating.'");';

 //echo $query;
  $result=$con->query($query);
  if ($result == TRUE) {}
	else {echo "Inserimento fallito" . $con->error;}
?>