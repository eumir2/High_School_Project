<?php
//file PHP che ricevuto l'id del punto, ne scarica le recensioni

//leggo l'id del punto
$idP = $_GET['idP'];
//echo $idP;

//mi connetto al database
$con = new mysqli("http://eumircometti.altervista.org","eumircometti","","my_eumircometti");
if($con -> connect_errno){
	die("Errore nella connnessione");
}

//estraggo li contenuto della tabella 'recensioni '
$query = "SELECT utenti.nome_utente, recensioni_punti.recensione, recensioni_punti.rating
		FROM utenti, recensioni_punti, punti_interesse
		WHERE utenti.idUtente = recensioni_punti.idUtente
		AND punti_interesse.idPunto_interesse = recensioni_punti.idPunto_interesse
        AND punti_interesse.idPunto_interesse = '$idP';";

//echo $query;
$heroes = array();  
$smt=$con->query($query);
  if ($smt == TRUE) {
  	//echo "Selezione ok";
	}else {
		echo "Selezione fallita" . $con->error;
	}

 //var_dump($stmt);
//looping through all the records
while($riga = $smt->fetch_assoc()){
 //pushing fetched data in an array 
 $temp = [
 'nomeU'=>$riga['nome_utente'],
 'note'=>$riga['recensione'],
 'rating'=>$riga['rating'],
 ];
 //var_dump($temp);
 //pushing the array inside the hero array 
 array_push($heroes, $temp);
}
 
//displaying the data in json format 
echo json_encode($heroes);

$con->close(); 
?>