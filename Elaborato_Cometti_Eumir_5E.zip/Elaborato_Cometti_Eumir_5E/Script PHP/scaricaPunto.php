<?php
//file PHP che ricevuto l'id del punto, ne scarica i dati

//leggo l'id del punto
$idP = $_GET['idP'];
//echo $idP;

//mi connetto al database
$con = new mysqli("http://eumircometti.altervista.org","eumircometti","","my_eumircometti");
if($con -> connect_errno){
	die("Errore nella connnessione");
}

//estraggo li contenuto della tabella 'punti_interesse'
$query = "SELECT * FROM punti_interesse
			WHERE idPunto_interesse = '$idP';";

//echo $query;
$heroes = array();  
$smt=$con->query($query);
  if ($smt == TRUE) {
  	//echo "Selezione ok";
	}else {
		echo "Selezione fallita" . $con->error;
	}

 //var_dump($stmt);
//looping through all the records
while($riga = $smt->fetch_assoc()){
 //pushing fetched data in an array 
 $temp = [
 'idPunto'=>$riga['idPunto_interesse'],
 'nome'=>$riga['nome'],
 'lat'=>$riga['lat'],
 'lon'=>$riga['lon'],
 'descrizione'=>$riga['descrizione'],
 'link'=>$riga['link'],
 'telefono'=>$riga['telefono'],
 ];
 //var_dump($temp);
 //pushing the array inside the hero array 
 array_push($heroes, $temp);
}
 
//displaying the data in json format 
echo json_encode($heroes);

$con->close(); 
?>